<script src="<?php echo e(asset('js/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/validate.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/venobox.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/aos.js')); ?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php /**PATH C:\Users\NguyenTham\gemifx\resources\views/layout/footer.blade.php ENDPATH**/ ?>