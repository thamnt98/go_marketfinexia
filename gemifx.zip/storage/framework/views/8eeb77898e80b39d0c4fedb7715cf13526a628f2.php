<!doctype html>
<html class="no-js" lang="ja">
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="">
<?php echo $__env->make('layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="main">
    <div id="loading" style="position: fixed;
        top: 50%;
        left: 50%;
        background-color: rgba(100,100,100,0.3);
        width: 100%;
        text-align: center;
        height: 100%;
        transform: translate(-50%,-50%); z-index: 99999999; display: none">
        <img src="<?php echo e(asset('img/Spinner-1s-800px.gif')); ?>" width="100" height="100" style="position: fixed;
        top: 50%;
        left: 50%;
        background-color: grey;
        /* width: 100%; */
        text-align: center;
        /* height: 100%; */
        transform: translate(-50%,-50%);">
    </div>
</div>
<?php echo $__env->make('layout.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\Users\NguyenTham\gemifx\resources\views/layout/page.blade.php ENDPATH**/ ?>