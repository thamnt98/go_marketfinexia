<script src="{{ asset('js/js/jquery.min.js')}}"></script>
<script src="{{ asset('js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('js/jquery.easing.min.js')}}"></script>
<script src="{{ asset('js/validate.js')}}"></script>
<script src="{{ asset('js/jquery.sticky.js')}}"></script>
<script src="{{ asset('js/isotope.pkgd.min.js')}}"></script>
<script src="{{ asset('js/venobox.min.js')}}"></script>
<script src="{{ asset('js/jquery.waypoints.min.js')}}"></script>
<script src="{{ asset('js/owl.carousel.min.js')}}"></script>
<script src="{{ asset('js/aos.js')}}"></script>

<!-- Template Main JS File -->
<script src="{{ asset('js/main.js')}}"></script>
